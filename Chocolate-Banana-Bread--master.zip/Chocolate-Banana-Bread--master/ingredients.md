1. 3/4 cup chocolate
2. 3 bananas
3. 1/2 stick unsalted butter
4. 1 1/4 cup brown sugar
5. Tiny sprikle of salt
6. 2 3/4 cups of flour
7. 1 egg