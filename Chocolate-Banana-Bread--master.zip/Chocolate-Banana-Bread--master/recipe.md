1. Mash bananas
2. Pour cups of flour into pan with melted butter
3. Mix egg
4. Pour sugar and add some salt
5. Add chocolate
6. Preheat oven about 350 degrees
7. Bake until bread is golden brown
8. Let it cool down
9. Eat